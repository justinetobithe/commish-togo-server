<?php

namespace App\Services;

class NotificationService
{
    public function __construct()
    {
    }
}